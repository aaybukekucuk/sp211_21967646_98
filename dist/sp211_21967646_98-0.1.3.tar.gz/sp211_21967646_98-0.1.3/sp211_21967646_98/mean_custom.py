def mean_custom(numbers):
    return sum(numbers) / len(numbers)